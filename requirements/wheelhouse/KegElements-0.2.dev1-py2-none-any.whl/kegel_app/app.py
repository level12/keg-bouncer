from keg.app import Keg


class KegElApp(Keg):
    import_name = 'kegel_app'
