WTForms-Alchemy
---------------

Generates WTForms forms from SQLAlchemy models.


