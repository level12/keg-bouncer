from __future__ import absolute_import

from flask import current_app

from keg.app import Keg

# silence linter
current_app
Keg
