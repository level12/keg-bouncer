VERSION = '0.2.dev1'
