import flask

keg_element_blueprint = flask.Blueprint('keg_element', __name__, template_folder='templates')
